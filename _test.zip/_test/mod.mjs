/**
 * filebox —— Cloudflare Worker + R2 文件托管
 *
 * 路由：
 *   GET  /               上传页 + 文件列表
 *   GET  /api/config     前端配置（是否要口令、要人机验证、大小与配额）
 *   GET  /api/list       文件列表 JSON
 *   POST /upload?name=x  上传（请求体就是文件本身）
 *   GET  /f/<key>        直链：图片/视频内联，危险类型强制下载
 *   GET  /f/<key>?dl=1   强制下载
 *   POST /d/<key>?token= 删除（需 ADMIN_TOKEN）
 *
 * 安全层次（由外到内）：
 *   1. 上传口令 UPLOAD_TOKEN        —— 只有拿到口令的人能传
 *   2. Turnstile 人机验证           —— 挡住脚本批量上传（配了 TURNSTILE_SECRET 才启用）
 *   3. 每 IP 每日配额 DAILY_FILES / DAILY_MB —— 挡住单个人刷爆存储
 *   4. 单文件大小上限 MAX_MB（含落盘后的事后校验，分块上传也绕不过）
 *   5. 危险扩展名强制下载 + nosniff  —— 防止在你的域名下执行别人传的页面
 *   6. 文件名净化                    —— 防路径穿越
 *
 * 计数器复用同一个 R2 桶（键前缀 _rate/），所以不需要额外建 KV。
 */

const DANGEROUS_EXT = new Set([
  'html', 'htm', 'xhtml', 'shtml', 'svg', 'xml', 'js', 'mjs', 'cjs', 'css',
  'exe', 'msi', 'bat', 'cmd', 'com', 'scr', 'ps1', 'psm1', 'sh', 'bash',
  'jar', 'apk', 'dll', 'vbs', 'hta', 'reg', 'lnk', 'swf', 'jsp', 'asp', 'php'
]);

const RATE_PREFIX = '_rate/';

const TYPE_MAP = {
  jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', gif: 'image/gif',
  webp: 'image/webp', avif: 'image/avif', bmp: 'image/bmp', ico: 'image/x-icon',
  svg: 'image/svg+xml', mp4: 'video/mp4', webm: 'video/webm', mov: 'video/quicktime',
  m4v: 'video/x-m4v', mp3: 'audio/mpeg', wav: 'audio/wav', ogg: 'audio/ogg',
  m4a: 'audio/mp4', flac: 'audio/flac', pdf: 'application/pdf', zip: 'application/zip',
  '7z': 'application/x-7z-compressed', rar: 'application/vnd.rar',
  txt: 'text/plain; charset=utf-8', md: 'text/plain; charset=utf-8',
  json: 'application/json', csv: 'text/csv', doc: 'application/msword',
  docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  xls: 'application/vnd.ms-excel',
  xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  ppt: 'application/vnd.ms-powerpoint',
  pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
};

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const p = url.pathname;
    if (request.method === 'OPTIONS') return new Response(null, { headers: { 'Access-Control-Allow-Origin': '*' } });

    try {
      if (p === '/' && request.method === 'GET') return page(env, url);
      if (p === '/api/config') return await config(request, env, url);
      if (p === '/api/list') return await listFiles(env, url);
      if (p === '/upload' && request.method === 'POST') return await upload(request, env, url);
      if (p.startsWith('/f/')) return await serve(request, env, url);
      if (p.startsWith('/d/')) return await remove(request, env, url);
      return new Response('404 Not Found', { status: 404 });
    } catch (err) {
      return json({ ok: false, error: String((err && err.message) || err) }, 500);
    }
  }
};

/* ---------------- 接口实现 ---------------- */

async function config(request, env, url) {
  const q = quotaConfig(env);
  const out = {
    ok: true,
    site: env.SITE_NAME || '文件盒',
    needToken: !!env.UPLOAD_TOKEN,
    maxMB: fnum(env.MAX_MB, 30),
    turnstileSiteKey: env.TURNSTILE_SITE_KEY || '',
    dailyFiles: q.files,
    dailyMB: q.mb
  };
  if (q.files > 0 || q.mb > 0) {
    const c = await readCounter(env, await ipKey(request, env));
    out.remainingFiles = q.files > 0 ? Math.max(0, q.files - c.files) : -1;
    out.remainingMB = q.mb > 0 ? Math.max(0, Math.round(q.mb - c.bytes / 1048576)) : -1;
  }
  return json(out);
}

async function listFiles(env, url) {
  const limit = Math.min(num(url.searchParams.get('limit'), 300), 1000);
  const listed = await env.BUCKET.list({ limit, include: ['httpMetadata', 'customMetadata'] });
  const files = listed.objects
    .filter((o) => !o.key.startsWith(RATE_PREFIX))          // 计数记录不算文件
    .map((o) => ({
      key: o.key,
      name: (o.customMetadata && o.customMetadata.name) || o.key,
      size: o.size,
      uploaded: o.uploaded,
      type: (o.httpMetadata && o.httpMetadata.contentType) || '',
      url: base(env, url) + '/f/' + o.key,
      download: base(env, url) + '/f/' + o.key + '?dl=1'
    }))
    .sort((a, b) => new Date(b.uploaded) - new Date(a.uploaded));
  return json({ ok: true, count: files.length, truncated: listed.truncated, files });
}

async function upload(request, env, url) {
  // ① 上传口令
  if (env.UPLOAD_TOKEN && url.searchParams.get('token') !== env.UPLOAD_TOKEN) {
    return json({ ok: false, error: '上传口令不正确' }, 403);
  }

  // ② 人机验证（配了密钥才启用）
  const turn = await verifyTurnstile(env, request, url.searchParams.get('cf-turnstile-response') || '');
  if (!turn.ok) return json({ ok: false, error: turn.error }, 403);

  // 客户端声明的长度（浏览器/XHR 一定会带；分块上传时可能没有）
  const declared = num(request.headers.get('content-length'), 0);
  const maxBytes = fnum(env.MAX_MB, 30) * 1024 * 1024;

  // ③ 每日配额：把"这一个文件"也算进去预判，否则会超出一整个文件的量
  const q = quotaConfig(env);
  let counterKey = null;
  let counter = { files: 0, bytes: 0 };
  if (q.files > 0 || q.mb > 0) {
    counterKey = await ipKey(request, env);
    counter = await readCounter(env, counterKey);
    if (q.files > 0 && counter.files >= q.files) {
      return json({ ok: false, error: '今天上传数量已达上限（' + q.files + ' 个），明天再来' }, 429);
    }
    if (q.mb > 0) {
      const limitBytes = q.mb * 1048576;
      const willUse = counter.bytes + (declared || 0);
      if (counter.bytes >= limitBytes || (declared && willUse > limitBytes)) {
        return json({ ok: false, error: '今天上传流量已达上限（' + q.mb + 'MB），明天再来' }, 429);
      }
    }
  }

  // ④ 单文件大小（头部声明的）
  if (declared && declared > maxBytes) return json({ ok: false, error: '超过 ' + fnum(env.MAX_MB, 30) + 'MB 上限' }, 413);
  if (!request.body) return json({ ok: false, error: '请求体为空' }, 400);

  const name = safeName(url.searchParams.get('name') || 'file');
  const ext = extOf(name);
  const key = shortId() + (ext ? '.' + ext : '');
  const contentType = request.headers.get('content-type') || TYPE_MAP[ext] || 'application/octet-stream';

  const obj = await env.BUCKET.put(key, request.body, {
    httpMetadata: { contentType },
    customMetadata: {
      name,
      ip: clientIp(request),
      ua: (request.headers.get('user-agent') || '').slice(0, 150)
    }
  });

  // ⑤ 事后兜底：分块上传没有 content-length，落盘后再量一次真实大小
  if (obj.size > maxBytes) {
    await env.BUCKET.delete(key);
    return json({ ok: false, error: '超过 ' + fnum(env.MAX_MB, 30) + 'MB 上限，已拒绝' }, 413);
  }

  // ⑥ 配额复核：客户端没带 content-length 时（分块上传）上面的预判会落空，
  //    所以按真实大小再核一次，超了就把刚写进去的删掉、且不计入配额
  if (counterKey && q.mb > 0) {
    const limitBytes = q.mb * 1048576;
    if (counter.bytes + obj.size > limitBytes) {
      await env.BUCKET.delete(key);
      return json({ ok: false, error: '今天上传流量已达上限（' + q.mb + 'MB），这个文件没有保存' }, 429);
    }
  }

  // ⑦ 计数
  let remaining = null;
  if (counterKey) {
    // ponytail: 这里的读-改-写不是原子操作，同一 IP 并发上传时可能略微超出配额。
    //           想严格限制就换成 D1（UPDATE ... RETURNING）或 Durable Object 串行化计数。
    counter.files += 1;
    counter.bytes += obj.size;
    await env.BUCKET.put(counterKey, JSON.stringify(counter), {
      httpMetadata: { contentType: 'application/json' },
      customMetadata: { rate: '1' }
    });
    remaining = {
      files: q.files > 0 ? Math.max(0, q.files - counter.files) : -1,
      mb: q.mb > 0 ? Math.max(0, Math.round(q.mb - counter.bytes / 1048576)) : -1
    };
  }

  return json({
    ok: true,
    key,
    name,
    size: obj.size,
    url: base(env, url) + '/f/' + key,
    download: base(env, url) + '/f/' + key + '?dl=1',
    remaining
  });
}

async function serve(request, env, url) {
  const key = decodeURIComponent(url.pathname.slice(3));
  const obj = await env.BUCKET.get(key);
  if (!obj) return new Response('文件不存在', { status: 404 });

  const headers = new Headers();
  obj.writeHttpMetadata(headers);
  const name = (obj.customMetadata && obj.customMetadata.name) || key;
  const ext = extOf(key);
  const ctype = headers.get('content-type') || 'application/octet-stream';
  const dangerous = DANGEROUS_EXT.has(ext);
  const forceDownload = dangerous || url.searchParams.get('dl') === '1';

  headers.set('Content-Type', ctype);
  headers.set('Content-Disposition', (forceDownload ? 'attachment' : 'inline') +
    "; filename*=UTF-8''" + encodeURIComponent(name));
  headers.set('X-Content-Type-Options', 'nosniff');
  headers.set('Content-Length', String(obj.size));
  headers.set('Cache-Control', 'public, max-age=31536000, immutable');
  headers.set('Access-Control-Allow-Origin', '*');
  if (request.method === 'HEAD') return new Response(null, { headers });
  return new Response(obj.body, { headers });
}

async function remove(request, env, url) {
  if (request.method !== 'POST' && request.method !== 'DELETE') return json({ ok: false, error: '请用 POST/DELETE' }, 405);
  if (!env.ADMIN_TOKEN || url.searchParams.get('token') !== env.ADMIN_TOKEN) {
    return json({ ok: false, error: '管理口令不正确' }, 403);
  }
  const key = decodeURIComponent(url.pathname.slice(3));
  await env.BUCKET.delete(key);
  return json({ ok: true, deleted: key });
}

/* ---------------- 人机验证 / 配额 ---------------- */

async function verifyTurnstile(env, request, token) {
  const secret = env.TURNSTILE_SECRET;
  if (!secret) return { ok: true, skipped: true };        // 没配密钥就不启用
  if (!token) return { ok: false, error: '缺少人机验证，请刷新页面重试' };
  const form = new FormData();
  form.append('secret', secret);
  form.append('response', token);
  const ip = request.headers.get('cf-connecting-ip');
  if (ip) form.append('remoteip', ip);
  let j = {};
  try {
    const r = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', { method: 'POST', body: form });
    j = await r.json();
  } catch (e) {
    return { ok: false, error: '人机验证服务暂时不可用' };
  }
  if (j && j.success) return { ok: true };
  return { ok: false, error: '人机验证未通过' };
}

function quotaConfig(env) {
  return { files: num(env.DAILY_FILES, 0), mb: fnum(env.DAILY_MB, 0) };
}

async function ipKey(request, env) {
  const ip = clientIp(request) + '|' + (env.UPLOAD_TOKEN ? 'p' : 'o');
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(ip));
  const hex = Array.from(new Uint8Array(buf), (b) => b.toString(16).padStart(2, '0')).join('').slice(0, 20);
  return RATE_PREFIX + hex + '_' + new Date().toISOString().slice(0, 10);
}

async function readCounter(env, key) {
  const o = await env.BUCKET.get(key);
  if (!o) return { files: 0, bytes: 0 };
  try {
    const j = JSON.parse(await o.text());
    return { files: num(j.files, 0), bytes: num(j.bytes, 0) };
  } catch (e) {
    return { files: 0, bytes: 0 };
  }
}

/* ---------------- 小工具 ---------------- */

function json(obj, status) {
  return new Response(JSON.stringify(obj), {
    status: status || 200,
    headers: { 'Content-Type': 'application/json; charset=utf-8', 'Access-Control-Allow-Origin': '*', 'Cache-Control': 'no-store' }
  });
}
function num(v, d) {
  const n = parseInt(v, 10);
  return Number.isFinite(n) ? n : d;
}
/* MB 类的值允许小数（例如 MAX_MB="2.5"）——用 parseInt 会把 0.5 抹成 0，
   那等于"限制被关掉"，是不安全的静默失败，所以这里单独用 parseFloat */
function fnum(v, d) {
  const n = parseFloat(v);
  return Number.isFinite(n) ? n : d;
}
function extOf(name) {
  const i = name.lastIndexOf('.');
  return i > 0 ? name.slice(i + 1).toLowerCase() : '';
}
function safeName(input) {
  let n = String(input).replace(/\\/g, '/');
  n = n.slice(n.lastIndexOf('/') + 1);
  n = n.replace(/[\u0000-\u001f\u007f]/g, '');
  n = n.replace(/^\.+/, '');
  if (!n) n = 'file';
  return n.length > 120 ? n.slice(-120) : n;
}
function shortId() {
  const bytes = new Uint8Array(8);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => b.toString(36).padStart(2, '0')).join('').slice(0, 12);
}
function clientIp(request) {
  return request.headers.get('cf-connecting-ip') || request.headers.get('x-forwarded-for') || 'unknown';
}
function base(env, url) {
  return (env.PUBLIC_BASE || url.origin).replace(/\/+$/, '');
}

/* ---------------- 前端页面 ---------------- */

function page(env, url) {
  const site = env.SITE_NAME || '文件盒';
  const html = `<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${site}</title>
<meta name="theme-color" content="#17181a">
<style>
  :root{color-scheme:dark}
  *{box-sizing:border-box}
  body{margin:0;padding:26px 16px 60px;background:#17181a;color:#c9ccd1;
       font:14px/1.7 'PingFang SC','Microsoft YaHei','Helvetica Neue',Arial,sans-serif}
  .wrap{max-width:920px;margin:0 auto}
  h1{margin:0 0 4px;font-size:24px;color:#e8eaf0}
  .sub{color:#7d838f;font-size:13px;margin-bottom:18px}
  #drop{border:2px dashed #3a3f52;border-radius:14px;padding:30px 20px;text-align:center;
        background:#1d1f27;cursor:pointer;transition:.2s}
  #drop:hover,#drop.over{border-color:#5B7BFF;background:#212433}
  #drop b{color:#e8eaf0}
  #drop .hint{font-size:12px;color:#7d838f;margin-top:6px}
  .row{display:flex;gap:10px;align-items:center;margin-top:14px;flex-wrap:wrap}
  input[type=password],input[type=text],#q{padding:9px 12px;background:#20222a;border:1px solid #2c2f3a;
        border-radius:9px;color:#e8eaf0;outline:none;font-size:13px}
  input:focus{border-color:#5B7BFF}
  #q{width:100%;margin:22px 0 12px}
  .bar{height:6px;background:#2a2e3a;border-radius:4px;overflow:hidden;margin-top:12px;display:none}
  .bar i{display:block;height:100%;width:0;background:linear-gradient(90deg,#5B7BFF,#e0566f);transition:width .15s}
  table{width:100%;border-collapse:collapse;background:#20222a;border:1px solid #2c2f3a;border-radius:10px;overflow:hidden}
  th,td{padding:10px 12px;text-align:left;border-bottom:1px solid #262932;vertical-align:top}
  th{font-size:12px;color:#98a0ad;background:#1c1e26}
  tr:last-child td{border-bottom:0}
  tr.hide{display:none}
  td.name{color:#e8eaf0;word-break:break-all}
  td.name a{color:#e8eaf0;text-decoration:none}
  td.name a:hover{color:#8ab4f8}
  td.kind,td.size,td.time{color:#98a0ad;font-size:12px;white-space:nowrap}
  .btn{display:inline-block;margin:0 6px 4px 0;padding:3px 9px;font-size:12px;color:#cfd6e4;
       background:#2a2e3a;border:1px solid #343846;border-radius:6px;cursor:pointer;text-decoration:none}
  .btn:hover{color:#fff;border-color:#5B7BFF;background:#303646}
  .btn.del:hover{border-color:#e0566f;color:#ffb3c6}
  #ts{margin-top:14px}
  #toast{position:fixed;left:50%;bottom:30px;transform:translate(-50%,20px);background:#2b3040;color:#fff;
         padding:9px 16px;border-radius:8px;font-size:13px;opacity:0;pointer-events:none;transition:.25s;
         box-shadow:0 8px 24px rgba(0,0,0,.5);z-index:9}
  #toast.on{opacity:1;transform:translate(-50%,0)}
  footer{margin-top:18px;color:#6f7581;font-size:12px;line-height:1.9}
  code{background:#23262f;padding:1px 6px;border-radius:4px;color:#9fd0ff;word-break:break-all}
</style>
</head>
<body>
<div class="wrap">
  <h1>${site}</h1>
  <div class="sub">拖进来就上传 · 每个文件都有直链，可外链可下载</div>

  <div id="drop">
    <b>把文件拖到这里</b>，或点击选择<br>
    <span class="hint" id="limit"></span>
  </div>
  <input type="file" id="pick" multiple style="display:none">

  <div class="row" id="tokenRow" style="display:none">
    <span style="color:#98a0ad;font-size:13px">上传口令：</span>
    <input type="password" id="token" placeholder="问站长要" style="min-width:220px">
    <button class="btn" id="saveToken">记住口令</button>
  </div>

  <div id="ts"></div>
  <div class="bar" id="bar"><i></i></div>

  <input id="q" type="search" placeholder="筛选文件名…">

  <table>
    <thead><tr><th>文件</th><th>类型</th><th>大小</th><th>上传时间</th><th>操作</th></tr></thead>
    <tbody id="tb"></tbody>
  </table>
  <footer>
    · 「直链」可直接粘到博客：图片用 <code>&lt;img&gt;</code>，视频用 <code>&lt;video&gt;</code>，其它给下载链接<br>
    · 危险类型（html/svg/js/exe…）一律强制下载，不会在你的域名下被执行<br>
    · 删除需要管理口令
  </footer>
</div>
<div id="toast"></div>

<script>
(function () {
  var cfg = { needToken: false, maxMB: 30, turnstileSiteKey: '', dailyFiles: 0, dailyMB: 0 };
  var token = localStorage.getItem('fb_token') || '';
  var admin = localStorage.getItem('fb_admin') || '';
  var drop = document.getElementById('drop');
  var pick = document.getElementById('pick');
  var tb = document.getElementById('tb');
  var bar = document.getElementById('bar');
  var barIn = bar.querySelector('i');
  var toast = document.getElementById('toast');
  var t;

  function say(msg) {
    toast.textContent = msg;
    toast.classList.add('on');
    clearTimeout(t);
    t = setTimeout(function () { toast.classList.remove('on'); }, 2200);
  }
  function human(b) {
    if (b >= 1048576) return (b / 1048576).toFixed(2) + ' MB';
    if (b >= 1024) return Math.round(b / 1024) + ' KB';
    return b + ' B';
  }
  function copy(text, msg) {
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(function () { say(msg); }, function () { fb(text, msg); });
    } else { fb(text, msg); }
  }
  function fb(text, msg) {
    var ta = document.createElement('textarea');
    ta.value = text; ta.style.position = 'fixed'; ta.style.left = '-9999px';
    document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); say(msg); } catch (e) { say('复制失败，请手动复制'); }
    document.body.removeChild(ta);
  }
  function kv(list) {
    return list.map(function (x) { return x[0] + '=' + encodeURIComponent(x[1]); }).join('&');
  }
  function snippet(f) {
    var ext = (f.name.split('.').pop() || '').toLowerCase();
    if (['mp4', 'webm', 'mov', 'm4v'].indexOf(ext) >= 0) {
      return '<video src="' + f.url + '" controls preload="metadata" style="max-width:100%"></video>';
    }
    if (['jpg', 'jpeg', 'png', 'webp', 'gif', 'avif', 'bmp'].indexOf(ext) >= 0) {
      return '<img src="' + f.url + '" alt="' + f.name + '" style="max-width:100%">';
    }
    return '<a href="' + f.url + '" target="_blank" rel="noopener">' + f.name + '</a>';
  }
  function tsToken() {
    var el = document.querySelector('[name="cf-turnstile-response"]');
    return el ? el.value : '';
  }

  function render(files) {
    tb.innerHTML = files.map(function (f) {
      return '<tr>' +
        '<td class="name"><a href="' + f.url + '" target="_blank" rel="noopener">' + f.name + '</a></td>' +
        '<td class="kind">' + (f.type || '-') + '</td>' +
        '<td class="size">' + human(f.size) + '</td>' +
        '<td class="time">' + new Date(f.uploaded).toLocaleString('zh-CN') + '</td>' +
        '<td class="ops">' +
          '<a class="btn" href="' + f.download + '">下载</a>' +
          '<button class="btn" data-copy="' + f.url + '">直链</button>' +
          '<button class="btn" data-snippet="' + encodeURIComponent(JSON.stringify(f)) + '">引用</button>' +
          '<button class="btn del" data-del="' + f.key + '">删除</button>' +
        '</td></tr>';
    }).join('') || '<tr><td colspan="5" style="color:#7d838f;text-align:center;padding:22px">还没有文件</td></tr>';
  }

  function load() {
    fetch('/api/list').then(function (r) { return r.json(); }).then(function (j) {
      if (j.ok) render(j.files); else say(j.error || '加载失败');
    }).catch(function () { say('加载失败'); });
  }

  function tip() {
    var parts = ['单个文件最大 ' + cfg.maxMB + 'MB'];
    if (cfg.needToken) parts.push('需要上传口令');
    if (cfg.dailyFiles > 0) parts.push('每人每天最多 ' + cfg.dailyFiles + ' 个');
    if (cfg.dailyMB > 0) parts.push('每天最多 ' + cfg.dailyMB + 'MB');
    if (cfg.turnstileSiteKey) parts.push('需过人机验证');
    document.getElementById('limit').textContent = parts.join(' · ');
  }

  function upload(files) {
    var list = Array.prototype.slice.call(files);
    if (!list.length) return;
    if (cfg.needToken && !token) { say('先填上传口令'); return; }
    if (cfg.turnstileSiteKey && !tsToken()) { say('请先完成人机验证'); return; }
    bar.style.display = 'block';
    (function next() {
      var file = list.shift();
      if (!file) { bar.style.display = 'none'; barIn.style.width = '0'; load(); say('全部上传完成'); return; }
      if (file.size > cfg.maxMB * 1048576) { say(file.name + ' 超过 ' + cfg.maxMB + 'MB，跳过'); return next(); }
      var qs = kv([['name', file.name]].concat(cfg.needToken ? [['token', token]] : []));
      if (cfg.turnstileSiteKey) qs += '&cf-turnstile-response=' + encodeURIComponent(tsToken());
      var xhr = new XMLHttpRequest();
      xhr.open('POST', '/upload?' + qs);
      xhr.setRequestHeader('Content-Type', file.type || 'application/octet-stream');
      xhr.upload.onprogress = function (e) {
        if (e.lengthComputable) barIn.style.width = Math.round(e.loaded / e.total * 100) + '%';
      };
      xhr.onload = function () {
        var res = {};
        try { res = JSON.parse(xhr.responseText); } catch (e) {}
        if (xhr.status === 200 && res.ok) {
          copy(res.url, file.name + ' 上传成功，直链已复制');
          if (res.remaining) {
            var r = res.remaining;
            if (r.files >= 0) cfg.dailyFiles && (document.getElementById('limit').dataset.f = r.files);
            tip();
          }
        } else {
          say(file.name + ' 上传失败：' + (res.error || xhr.status));
        }
        next();
      };
      xhr.onerror = function () { say(file.name + ' 网络错误'); next(); };
      xhr.send(file);
    })();
  }

  drop.addEventListener('click', function () { pick.click(); });
  pick.addEventListener('change', function () { upload(pick.files); pick.value = ''; });
  ['dragenter', 'dragover'].forEach(function (n) {
    drop.addEventListener(n, function (e) { e.preventDefault(); drop.classList.add('over'); });
  });
  ['dragleave', 'drop'].forEach(function (n) {
    drop.addEventListener(n, function (e) { e.preventDefault(); drop.classList.remove('over'); });
  });
  drop.addEventListener('drop', function (e) { upload(e.dataTransfer.files); });

  document.getElementById('q').addEventListener('input', function () {
    var kw = this.value.trim().toLowerCase();
    Array.prototype.forEach.call(tb.querySelectorAll('tr'), function (tr) {
      var a = tr.querySelector('.name a');
      tr.classList.toggle('hide', !!(a && a.textContent.toLowerCase().indexOf(kw) < 0));
    });
  });

  document.addEventListener('click', function (e) {
    var el = e.target;
    if (!el.dataset) return;
    if (el.dataset.copy) copy(el.dataset.copy, '直链已复制');
    else if (el.dataset.snippet) copy(snippet(JSON.parse(decodeURIComponent(el.dataset.snippet))), '引用代码已复制');
    else if (el.dataset.del) {
      if (!admin) { admin = prompt('输入管理口令：') || ''; if (!admin) return; localStorage.setItem('fb_admin', admin); }
      fetch('/d/' + el.dataset.del + '?token=' + encodeURIComponent(admin), { method: 'POST' })
        .then(function (r) { return r.json(); })
        .then(function (j) { if (j.ok) { say('已删除'); load(); } else { say(j.error || '删除失败'); admin = ''; localStorage.removeItem('fb_admin'); } });
    }
  });

  document.getElementById('saveToken').addEventListener('click', function () {
    token = document.getElementById('token').value.trim();
    localStorage.setItem('fb_token', token);
    say(token ? '口令已记住' : '口令已清空');
  });

  fetch('/api/config').then(function (r) { return r.json(); }).then(function (j) {
    cfg = j;
    if (j.needToken) {
      document.getElementById('tokenRow').style.display = 'flex';
      document.getElementById('token').value = token;
    }
    if (j.turnstileSiteKey) {
      // Turnstile 官方脚本，显式渲染到 #ts
      var s = document.createElement('script');
      s.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';
      s.async = true; s.defer = true;
      s.onload = function () {
        if (window.turnstile) {
          window.turnstile.render('#ts', { sitekey: j.turnstileSiteKey, theme: 'dark' });
        }
      };
      document.head.appendChild(s);
    }
    tip();
    load();
  }).catch(function () { load(); });
})();
</script>
</body>
</html>`;
  return new Response(html, {
    headers: { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' }
  });
}
