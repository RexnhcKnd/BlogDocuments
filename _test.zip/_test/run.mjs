
import box from './mod.mjs';

const store = new Map();
const BUCKET = {
  async put(key, body, opts) {
    const buf = body instanceof ReadableStream ? Buffer.from(await new Response(body).arrayBuffer()) : Buffer.from(body);
    store.set(key, { buf, httpMetadata:(opts&&opts.httpMetadata)||{}, customMetadata:(opts&&opts.customMetadata)||{}, uploaded:new Date() });
    return { size: buf.length };
  },
  async get(key) {
    const o = store.get(key); if (!o) return null;
    return { body:new Response(o.buf).body, size:o.buf.length, uploaded:o.uploaded,
      httpMetadata:o.httpMetadata, customMetadata:o.customMetadata,
      async text(){ return o.buf.toString('utf8'); },
      writeHttpMetadata(h){ for (const k in o.httpMetadata) h.set(k, o.httpMetadata[k]); } };
  },
  async list(){ return { objects:[...store.entries()].map(([key,o])=>({ key, size:o.buf.length, uploaded:o.uploaded, httpMetadata:o.httpMetadata, customMetadata:o.customMetadata })), truncated:false }; },
  async delete(key){ store.delete(key); }
};

const env = { BUCKET, MAX_MB:'30', UPLOAD_TOKEN:'', ADMIN_TOKEN:'admin123', SITE_NAME:'测试盒', PUBLIC_BASE:'', DAILY_FILES:'0', DAILY_MB:'0' };
const call = (path, init) => box.fetch(new Request('https://box.test'+path, init), env, {});
// 指定来源 IP 的调用器：配额是按 IP 记的，测配额时必须给每个用例独立 IP
const callIp = (ip) => (path, init) => {
  // 注意：不能用 Object.assign({headers:{ip}}, init)，那样 init.headers 会把 IP 头整个覆盖掉
  const headers = Object.assign({ 'cf-connecting-ip': ip }, (init && init.headers) || {});
  return box.fetch(new Request('https://box.test' + path, Object.assign({}, init, { headers })), env, {});
};

let pass=0, fail=0;
const ok=(c,m)=>{ if(c){pass++;console.log('  ✓ '+m);} else {fail++;console.log('  ✗ '+m);} };

console.log('— 基础流程 —');
let j = await (await call('/upload?name='+encodeURIComponent('我的测试 文件.txt'), { method:'POST', body:'hello 你好', headers:{'content-type':'text/plain'} })).json();
const key=j.key; ok(j.ok && j.size>0, '上传成功 key='+key);
ok(/\/f\/[a-z0-9]+(\.txt)?$/.test(j.url), '返回直链: '+j.url);
let r = await call('/f/'+key);
ok((await r.text())==='hello 你好', '直链内容一致（中文正常）');
ok((r.headers.get('content-disposition')||'').includes('inline'), 'txt 内联');
ok(r.headers.get('x-content-type-options')==='nosniff', '带 nosniff');
r = await call('/f/'+key+'?dl=1');
ok((r.headers.get('content-disposition')||'').startsWith('attachment'), '?dl=1 强制下载');
j = await (await call('/api/list')).json();
ok(j.ok && j.count===1 && j.files[0].name==='我的测试 文件.txt', '列表正确');

console.log('— 安全 —');
j = await (await call('/upload?name=evil.html', { method:'POST', body:'<script>alert(1)</script>' })).json();
r = await call('/f/'+j.key);
ok((r.headers.get('content-disposition')||'').startsWith('attachment'), 'html 强制下载（不在你域名下执行）');
j = await (await call('/upload?name='+encodeURIComponent('../../etc/passwd'), { method:'POST', body:'x' })).json();
ok(j.name==='passwd', '路径穿越清理为 passwd');
r = await call('/d/'+key, { method:'POST' }); ok(r.status===403, '无口令删除 403');
r = await call('/d/'+key+'?token=bad', { method:'POST' }); ok(r.status===403, '错口令删除 403');
ok((await (await call('/d/'+key+'?token=admin123', { method:'POST' })).json()).ok, '对的口令删除成功');

console.log('— 上传口令 —');
env.UPLOAD_TOKEN='secret';
r = await call('/upload?name=a.txt', { method:'POST', body:'x' }); ok(r.status===403, '无口令上传被拒');
r = await call('/upload?name=a.txt&token=secret', { method:'POST', body:'x' }); ok(r.status===200, '带口令可上传');
env.UPLOAD_TOKEN='';

console.log('— 单文件大小 —');
env.MAX_MB='0';
r = await call('/upload?name=big.bin', { method:'POST', body:'xxxx', headers:{'content-length':'4'} });
ok(r.status===413, '有 content-length 超限 413');
r = await call('/upload?name=chunked.bin', { method:'POST', body:'xxxxxxxxxx' });
ok(r.status===413, '无 content-length 也被拦（落盘后兜底）');
env.MAX_MB='30';

console.log('— 每人每天配额 —');
env.DAILY_FILES='2'; env.DAILY_MB='0';
const cA = callIp('1.1.1.1');
ok((await cA('/upload?name=q1.txt', { method:'POST', body:'1' })).status===200, '同一个人：第 1 个成功');
ok((await cA('/upload?name=q2.txt', { method:'POST', body:'2' })).status===200, '同一个人：第 2 个成功');
r = await cA('/upload?name=q3.txt', { method:'POST', body:'3' });
j = await r.json();
ok(r.status===429 && /数量/.test(j.error||''), '同一个人：第 3 个被拒 429');
r = await callIp('2.2.2.2')('/upload?name=other.txt', { method:'POST', body:'x' });
ok(r.status===200, '换个人（另一个 IP）不受影响，仍然能传');

env.DAILY_FILES='0'; env.DAILY_MB='0.00025';   // ≈262 字节
const cB = callIp('3.3.3.3');
j = await (await cB('/upload?name=m1.txt', { method:'POST', body:'x'.repeat(200), headers:{'content-length':'200'} })).json();
ok(j.ok===true, 'MB 配额：第 1 个 200 字节成功');
r = await cB('/upload?name=m2.txt', { method:'POST', body:'x'.repeat(200) });
j = await r.json();
ok(r.status===429 && /流量/.test(j.error||''), 'MB 配额：第 2 个会超限，上传前就被拦（'+j.error+'）');
ok((await (await callIp('3.3.3.3')('/api/config')).json()).remainingMB===0, '/api/config 显示剩余 0MB');
env.DAILY_MB='0';

// 小数 MAX_MB 也必须生效（以前 parseInt 会把它抹成 0 = 关掉限制）
const cC = callIp('4.4.4.4');
env.MAX_MB='0.0001';   // ≈104 字节
r = await cC('/upload?name=fraction.bin', { method:'POST', body:'x'.repeat(200) });
ok(r.status===413, '小数 MAX_MB 生效（200 字节 > 0.0001MB）');
j = await (await call('/api/config')).json();
ok(j.maxMB===0.0001, '/api/config 里 maxMB 保留小数: '+j.maxMB);
env.MAX_MB='30';

console.log('— 计数器不该出现在文件列表里 —');
j = await (await call('/api/list')).json();
ok(j.files.every(f=>!f.key.startsWith('_rate/')), '列表里没有 _rate/ 记录（当前 '+j.count+' 个文件）');
ok([...store.keys()].some(k=>k.startsWith('_rate/')), '但计数记录确实写进了存储桶');

console.log('— Turnstile 人机验证 —');
const realFetch = globalThis.fetch;
env.TURNSTILE_SECRET='s3cret';
env.DAILY_FILES='0'; env.DAILY_MB='0';
r = await call('/upload?name=t1.txt', { method:'POST', body:'x' });
ok(r.status===403, '没带 turnstile 令牌被拒 403');
globalThis.fetch = async () => ({ json: async () => ({ success:false }) });
r = await call('/upload?name=t2.txt&cf-turnstile-response=badtoken', { method:'POST', body:'x' });
ok(r.status===403, '令牌无效被拒 403');
globalThis.fetch = async () => ({ json: async () => ({ success:true }) });
r = await call('/upload?name=t3.txt&cf-turnstile-response=goodtoken', { method:'POST', body:'x' });
ok(r.status===200, '令牌有效放行 200');
globalThis.fetch = realFetch;
env.TURNSTILE_SECRET='';

console.log('— /api/config —');
j = await (await call('/api/config')).json();
ok(j.ok && j.maxMB===30 && typeof j.needToken==='boolean', '返回了 maxMB / needToken / 人机验证密钥');

console.log('\n通过 '+pass+' 项，失败 '+fail+' 项');
process.exit(fail?1:0);
