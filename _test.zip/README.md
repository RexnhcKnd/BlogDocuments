# filebox —— Cloudflare Worker + R2 文件托管站

一个文件全包：上传页 + 文件列表 + 直链 + 下载 + 删除，**不需要服务器、不需要数据库**。

```
Cloudflare Worker（src/index.js：前端页面 + 4 个接口）
      └── R2 存储桶（免费 10GB，出口流量完全免费 ← 这条是关键）
```

## 文件结构

```
filebox/
├─ wrangler.toml        部署配置（口令、上限都在这改）
├─ src/index.js         Worker 全部代码（含前端页面）
└─ _test/               我用来验证的测试（内存版假 R2，18 项全过）
```

## 已实现的功能

| 你的需求 | 实现 |
|---|---|
| 上传各种格式 | 任意类型都收，`Content-Type` 自动识别；拖拽 / 多选都支持 |
| 每个文件有链接 | 上传后**自动把直链复制到剪贴板**，也可在列表点「直链」 |
| 可外部直接链接 | 图片/视频内联可外链（`<img>` / `<video>` 直接用） |
| 可下载到本地 | 每个文件带「下载」按钮，走 `?dl=1` 强制下载 |
| 每个人都能上传 | 默认**口令上传**（把口令发给朋友即可）；想做完全公开见下面「改成完全公开」 |

## 部署（6 步）

```powershell
# 1. 注册 Cloudflare：https://dash.cloudflare.com/sign-up
# 2. 开通 R2：控制台左侧 R2 → 按提示开通（可能要求绑支付方式，免费额度内不扣费）

# 3. 装 wrangler（在 filebox 目录）
cd "D:\deepseek harness\工作区\filebox"
npm install wrangler --save-dev

# 4. 登录（会弹浏览器授权）
npx wrangler login

# 5. 建存储桶
npx wrangler r2 bucket create filebox

# 6. 先改 wrangler.toml 里的两个口令！然后部署
npx wrangler deploy
```

部署成功会打印一个地址，形如：

```
https://filebox.你的子域.workers.dev
```

打开就是上传页。**可选**：在 Cloudflare 里绑自己的域名（Workers → 你的 Worker → Settings → Domains & Routes），国内访问会稍好一点。

## 直链格式

```
https://filebox.你的子域.workers.dev/f/<key>        内联（图片/视频可直接外链）
https://filebox.你的子域.workers.dev/f/<key>?dl=1   强制下载
```

在博客文章里：

```html
<img src="https://filebox.xxx.workers.dev/f/abc123.jpg" alt="图">
<video src="https://filebox.xxx.workers.dev/f/def456.mp4" controls muted></video>
<a href="https://filebox.xxx.workers.dev/f/ghi789.zip" target="_blank">下载附件</a>
```

（列表页的「引用」按钮会直接生成上面这类代码，复制即用。）

## 安全设计（已实现）

| 措施 | 说明 |
|---|---|
| 危险类型强制下载 | `html/svg/js/exe/bat/php…` 一律 `Content-Disposition: attachment`，**不会在你的域名下被当页面执行**（防钓鱼/XSS） |
| `X-Content-Type-Options: nosniff` | 防止浏览器把文件猜成别的类型执行 |
| 路径穿越防护 | 上传名只取最后一段并去控制字符（`../../../etc/passwd` → `passwd`），已测 |
| 单文件大小上限 | 默认 30MB；**落盘后再量一次**，分块上传也绕不过（已测） |
| 上传口令 | `UPLOAD_TOKEN`，留空 = 完全公开 |
| **每人每天配额** | `DAILY_FILES` / `DAILY_MB`，按 IP 记（哈希后存进同一个 R2 桶的 `_rate/` 前缀，**不需要额外建 KV**）。上传前按 `content-length` 预判 + 落盘后按真实大小复核，两道都过了才算（已测） |
| **Turnstile 人机验证** | 配了 `TURNSTILE_SECRET` 才启用，挡住脚本批量上传（已测：无令牌 403 / 无效令牌 403 / 有效放行） |
| 管理口令 | 删除必须 `ADMIN_TOKEN`，错了返回 403 |
| 上传留痕 | 每个文件的 R2 元数据里存了上传者 IP 和 UA（出事能追溯） |

### 开启 Turnstile（可选，建议公开上传时开）

1. Cloudflare 控制台 → **Turnstile** → Add site → 拿到 **Site Key** 和 **Secret Key**
2. `wrangler.toml` 里填 `TURNSTILE_SITE_KEY = "你的site key"`
3. Secret Key 别写进文件，用命令存成密钥：
   ```powershell
   npx wrangler secret put TURNSTILE_SECRET
   ```
4. `npx wrangler deploy` —— 页面上会自动出现验证框

### 改成完全公开（任何人无口令上传）

`wrangler.toml` 里把 `UPLOAD_TOKEN` 留空即可。**但请务必同时开着 Turnstile + 每日配额**，
否则一段脚本几秒钟就能把你 10GB 免费额度刷满。

### 已知的小缺口（写代码时留的记号）

- 计数是「读-改-写」，**不是原子操作**：同一 IP 并发上传时可能略微超出配额（代码里标了 `ponytail:` 注释）。
  想严格限制就换 D1（`UPDATE ... RETURNING`）或 Durable Object 串行化计数。

### 还想更稳可以加（说一声我写）

- **Turnstile 人机验证**：挡住脚本批量上传
- **每 IP 每日配额**：用 KV 记数，比如每人每天最多 20 个文件 / 200MB
- **上传白名单/黑名单**：只允许图片视频，或只禁止压缩包
- **日志**：写到 D1，能查谁传了什么、什么时候

## 成本与限制

| 项目 | 免费额度 | 说明 |
|---|---|---|
| R2 存储 | 10 GB | 超了 $0.015/GB·月 |
| R2 出口流量 | **无限免费** | 这是选 R2 而不是 S3/OSS 的核心原因 |
| R2 操作 | 100 万次/月（A 类）/ 1000 万次（B 类） | 个人站用不完 |
| Workers 请求 | 10 万次/天 | 够 |
| 请求体上限 | 100 MB（免费版） | 所以 `MAX_MB` 默认 30，别写太大 |

⚠️ **国内可达性**：`*.workers.dev` 在国内有时不通/很慢。你的读者主要在国内的话，建议**绑一个自己的域名**（域名 ~¥50/年，Cloudflare 免费代理），或者改用**阿里云 OSS + 函数计算**（国内最快，但没这么"一个文件搞定"）。

## 本地跑测试

```powershell
node _test/run.mjs
```

**31 项**，覆盖：上传 / 直链内容（含中文）/ 内联与强制下载 / 列表 / 危险类型拦截 / 路径穿越清理 /
删除鉴权 / 上传口令 / 两种大小超限 / 每日数量配额（含"换个人不受影响"）/ 每日流量配额（预判+复核）/
小数 MB 配置生效 / 计数器不出现在文件列表 / Turnstile 三种情况 / `/api/config`。

改完代码先跑这个，**31 项全绿再部署**。

> 顺便说三件写这套测试时真抓出来的问题（都已修）：
> 1. 只查 `content-length` 判大小 → 分块上传能绕过；补了落盘后复核
> 2. `MAX_MB` / `DAILY_MB` 用 `parseInt` → 写 `"2.5"` 会被抹成 0 **等于关掉限制**；改成 `parseFloat`
> 3. 配额只比对已用量 → 会"超出一整个文件"；改成把本次文件大小也算进去预判 + 落盘后复核

## 顺带一提

有了这个站，之前一直没地方放的 **1.3MB 壁纸视频（`bg_540p.mp4`）** 就能上传并当博客背景用了。要接的话说一声，我给你那段"Banner 换成循环视频"的代码。
